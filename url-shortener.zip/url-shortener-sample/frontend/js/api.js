const Api = {
  base: 'http://localhost:8081/api/url',

  async shorten(longUrl) {
    const res = await this.post('', { longUrl }); // POST to /api/url
    const data = await res.safeJson();

    if (!res.ok) throw new Error(data.error || 'Unknown error');
    return data.shortUrl; // ← THIS is what we want to return
  },

  async get(path)  { return this.request('GET',  path); },
  async post(path, body) { return this.request('POST', path, body); },

  async request(method, path, body) {
    const headers = { 'Content-Type': 'application/json' };
    return fetch(this.base + path, {
      method, headers,
      body: body ? JSON.stringify(body) : undefined
    });
  },

  flash(elId, html) {
    document.getElementById(elId).innerHTML = html;
  }
};

// Adds .safeJson to Response prototype
Response.prototype.safeJson = async function () {
  const text = await this.text();
  return text ? JSON.parse(text) : {};
};
