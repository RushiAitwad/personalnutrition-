
document.getElementById('shorten-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const url = document.getElementById('long-url').value;
  const custom = document.getElementById('custom-slug').value;
  const res = await fetch('/api/url', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ url, custom })
  });
  const json = await res.json();
  const result = document.getElementById('result');
  if (json.shortUrl) {
    result.innerHTML = '<strong>Short URL:</strong> <a href="' + json.shortUrl + '" target="_blank">' + json.shortUrl + '</a>';
  } else {
    result.textContent = json.error || 'Something went wrong';
  }
});
