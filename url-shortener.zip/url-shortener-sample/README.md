
# Tiny Java URL Shortener (Preview)

A minimal proof‑of‑concept URL shortener using **Java 17**’s built‑in `HttpServer`, embedded **H2`,
and a vanilla HTML/CSS/JS front‑end.

## Run locally

```bash
cd backend
mvn package exec:java -Dexec.mainClass=dev.example.url.Main
```

Then open <http://localhost:8080> in your browser.

## Tech

* Java 17 (`com.sun.net.httpserver.HttpServer`)
* H2 (embedded, file‑based)
* SLF4J + Logback
* JUnit 5 / Mockito (unit tests)
* Plain HTML / CSS / JS on the client

> **Note:** Authentication and a richer feature set will be added in subsequent iterations.
