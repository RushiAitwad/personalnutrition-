
package dev.example.url.model;

public record Url(String slug, String longUrl, Long userId) {}
