package dev.example.url.controller;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import dev.example.url.dao.UrlDao;
import dev.example.url.service.UrlService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.stream.Collectors;

public class UrlController implements HttpHandler {
    private static final Logger log = LoggerFactory.getLogger(UrlController.class);
    private final UrlService service = new UrlService(new UrlDao());

    @Override
    public void handle(HttpExchange exchange) throws IOException {
        if ("OPTIONS".equalsIgnoreCase(exchange.getRequestMethod())) {
            exchange.getResponseHeaders().add("Access-Control-Allow-Origin", "*");
            exchange.getResponseHeaders().add("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
            exchange.getResponseHeaders().add("Access-Control-Allow-Headers", "Content-Type");
            exchange.sendResponseHeaders(204, -1);
            return;
        }

        // Always allow CORS on actual requests too
        exchange.getResponseHeaders().add("Access-Control-Allow-Origin", "*");

        // Continue as normal...
        String path = exchange.getRequestURI().getPath();
        String method = exchange.getRequestMethod();

        if ("/api/url".equals(path) && "POST".equalsIgnoreCase(method)) {
            handleShorten(exchange);
        } else if (path.startsWith("/u/") && "GET".equalsIgnoreCase(method)) {
            handleRedirect(exchange);
        } else {
            exchange.sendResponseHeaders(405, -1); // Method Not Allowed
        }
    }


    private void handleShorten(HttpExchange exchange) throws IOException {
        try (InputStream is = exchange.getRequestBody()) {
            String body = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))
                    .lines().collect(Collectors.joining("\n"));

            Map<String, String> data = parseJson(body);
            String longUrl = data.get("longUrl");
            if (longUrl == null || longUrl.isBlank()) {
                sendJson(exchange, HttpURLConnection.HTTP_BAD_REQUEST, "{\"error\":\"Missing longUrl\"}");
                return;
            }

            String slug = service.shorten(longUrl); // simplified: no custom slug

            String origin = "http://" + exchange.getLocalAddress().getHostName() + ":" + exchange.getLocalAddress().getPort();
            String jsonResponse = String.format("{\"shortUrl\":\"%s/u/%s\"}", origin, slug);
            sendJson(exchange, HttpURLConnection.HTTP_OK, jsonResponse);

        } catch (IllegalArgumentException ex) {
            sendJson(exchange, HttpURLConnection.HTTP_BAD_REQUEST, String.format("{\"error\":\"%s\"}", ex.getMessage()));
        }
    }

    private void handleRedirect(HttpExchange exchange) throws IOException {
        URI uri = exchange.getRequestURI();
        String slug = uri.getPath().substring("/u/".length());
        String longUrl = service.resolve(slug);

        if (longUrl != null) {
            exchange.getResponseHeaders().add("Location", longUrl);
            exchange.sendResponseHeaders(HttpURLConnection.HTTP_MOVED_TEMP, -1);
        } else {
            String response = "Short URL not found";
            exchange.sendResponseHeaders(HttpURLConnection.HTTP_NOT_FOUND, response.length());
            exchange.getResponseBody().write(response.getBytes(StandardCharsets.UTF_8));
        }
    }

    private void sendJson(HttpExchange exchange, int statusCode, String json) throws IOException {
        byte[] bytes = json.getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", "application/json");
        exchange.sendResponseHeaders(statusCode, bytes.length);
        exchange.getResponseBody().write(bytes);
    }

    private Map<String, String> parseJson(String json) {
        if (json == null || json.isBlank()) return Map.of();
        return java.util.Arrays.stream(json.trim().replaceAll("[{}\"]", "").split(","))
                .map(pair -> pair.split(":", 2))
                .filter(pair -> pair.length == 2)
                .collect(Collectors.toMap(
                        pair -> pair[0].trim(),
                        pair -> pair[1].trim()
                ));
    }
}
