
package dev.example.url;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public final class Database {
    private static final String JDBC_URL = "jdbc:h2:file:./data/url-shortener;AUTO_SERVER=TRUE";

    static {
        try {
            initSchema();
        } catch (SQLException e) {
            throw new ExceptionInInitializerError(e);
        }
    }

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(JDBC_URL, "sa", "");
    }

    private static void initSchema() throws SQLException {
        String ddl = "CREATE TABLE IF NOT EXISTS urls (" +
                     "slug VARCHAR(32) PRIMARY KEY," +
                     "long_url VARCHAR(2048) NOT NULL," +
                     "user_id BIGINT," +
                     "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP" +
                     ");";
        try (Connection conn = getConnection(); Statement st = conn.createStatement()) {
            st.execute(ddl);
        }
    }

    private Database() {}
}
