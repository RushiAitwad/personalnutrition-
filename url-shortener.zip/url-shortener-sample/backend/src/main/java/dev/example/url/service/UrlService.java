
package dev.example.url.service;

import dev.example.url.dao.UrlDao;
import dev.example.url.model.Url;

import java.security.SecureRandom;
import java.util.Random;
import java.util.stream.Collectors;

public class UrlService {
    private final UrlDao dao;
    private static final String ALPHABET = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    private final Random rnd = new SecureRandom();

    public UrlService(UrlDao dao) {
        this.dao = dao;
    }

    public String shorten(String longUrl) {
        String slug;
        do {
            slug = randomSlug();
        } while (dao.exists(slug));
        dao.insert(new Url(slug, longUrl, null));
        return slug;
    }


    private String randomSlug() {
        return rnd.ints(6, 0, ALPHABET.length())
                .mapToObj(ALPHABET::charAt)
                .collect(StringBuilder::new, StringBuilder::append, StringBuilder::append)
                .toString();
    }

    public String resolve(String slug) {
        return dao.resolve(slug);
    }
}
