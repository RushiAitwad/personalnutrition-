package dev.example.url.dao;

import dev.example.url.model.Url;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class UrlDao {

    // slug → longUrl (no persistence; use H2 later)
    private final Map<String, String> store = new ConcurrentHashMap<>();

    /**
     * Check if a slug is already taken
     */
    public boolean exists(String slug) {
        return store.containsKey(slug);
    }

    /**
     * Persist a new short ↔ long mapping
     */
    public void insert(Url url) {
        store.put(url.slug(), url.longUrl());
        // optional: log or count clicks later
    }

    /**
     * Look up the long URL by slug for redirects
     */
    public String resolve(String slug) {
        return store.get(slug);
    }
}
