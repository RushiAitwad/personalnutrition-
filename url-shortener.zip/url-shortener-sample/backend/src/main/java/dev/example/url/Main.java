package dev.example.url;

import com.sun.net.httpserver.HttpServer;
import dev.example.url.controller.UrlController;
import dev.example.url.controller.StaticFileHandler;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.file.Path;
import java.util.concurrent.Executors;

public class Main {
    public static void main(String[] args) throws IOException {
        int port = 8081;
        HttpServer server = HttpServer.create(new InetSocketAddress(port), 0);

        server.createContext("/api/url", new UrlController());
        server.createContext("/u", new UrlController()); // redirect handler
        server.createContext("/", new StaticFileHandler(Path.of("frontend")));

        server.setExecutor(Executors.newCachedThreadPool());
        server.start();

        LoggerFactory.getLogger(Main.class).info("Server started on port {}", port);
    }
}
